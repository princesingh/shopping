function display(value1,value2){
	document.getElementById(value1).style.display = 'block';
	document.getElementById('change_background').style.display = 'block';
}
function hide(value1,value2){
	document.getElementById('change_background').style.display = 'none';
	document.getElementById(value1).style.display = 'none';
}
var i=0;

function show_message(value){
	document.getElementById('display_slide').style.backgroundColor = 'white';
	document.getElementById(value).style.display = 'block';
	i=i+2;
	document.getElementById(value).style.zIndex = i;
}

function get_product(){
	document.getElementById('change_background').style.display = 'none';
	var search_item = document.getElementById('enquered_product').value;
	var max_price = 100;
	if(search_item != ''){
		window.scrollTo(0, 0);
		var xmlhttpsignup;
		if(window.XMLHttpRequest){
			xmlhttpsignup = new XMLHttpRequest();
			
		}else{
			xmlhttpsignup = new ActiveXObject("Microsoft.XMLHTTP");
		}
		params = "search_item=" +search_item;
		
		xmlhttpsignup.open("POST","get_product.php",true);
		
		
		xmlhttpsignup.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttpsignup.setRequestHeader("Content-length", params.length);
		xmlhttpsignup.setRequestHeader("Connection", "close");
		
		xmlhttpsignup.onreadystatechange=function(){
		  if(xmlhttpsignup.status==200 && xmlhttpsignup.readyState==4){
			  document.getElementById("display_product").style.paddingBottom = '10px';
			   var returned_json = JSON.parse(xmlhttpsignup.responseText);
			   var currency_rs = '&#8377;';
			   document.getElementById('display_product').innerHTML='';
			   
			   for(var iota=0;iota<returned_json.length;iota++){
				   if(returned_json[iota]['old_price'] == 0){
					   returned_json[iota]['old_price'] = '';
				   }
				   var company;
				   if(returned_json[iota]['company'] == 'Flipkart'){
					   company = 'flipkart.jpg';
				   }else{
					   company = 'amazon.jpg';
				   }
				   returned_json[iota]['price'] = parseInt(returned_json[iota]['price']);
				   if(returned_json[iota]['price'] > max_price){
					   max_price = returned_json[iota]['price'];
				   }
				   document.getElementById('display_product').innerHTML +=  "<div onclick=diplay_detail("+returned_json[iota]['id']+",'online') style='width:226px;margin-left:8px; margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+returned_json[iota]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(returned_json[iota]['title'].substr(0,30)).toLowerCase()+"</div></div><div style='width:100%;float:left;text-align:center;opacity:0.7;background-color:white;color:black;margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+ returned_json[iota]['price'] +"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+returned_json[iota]['old_price']+"</div></div><div style='position:absolute;top:2px;right:2px;width:30px;height:30px'><img src='images/"+company+"' style='width:30px;height:30px' /></div></div></div>";
			   }
			   document.getElementById("show_data").style.display = 'block';
			   document.getElementById("page_price_slider").setAttribute('max',max_price);
			   document.getElementById("slider_min_value").innerHTML = "&#8377;"+0+"-->";
			   document.getElementById("slider_max_value").innerHTML = max_price;
			   document.getElementById("page_price_slider").value = max_price;
		   }
		}
		
		xmlhttpsignup.send(params);
		
		document.getElementById('display_product').innerHTML = "<div style='width:100px;height:68px;margin:0 auto;'><img src='images/loading.gif' style='max-width:100px;max-height:68px' /></div>"; 
		document.getElementById("show_data").style.display = 'none';
		
		get_offline(search_item);
		document.getElementById("twitter").style.display = "block";
		
		document.getElementById("twitter_holder").innerHTML = "<iframe width='250px' height='1200px' src='https://www.hashatit.com/hashtags/"+search_item+"/twitter/embed'></iframe>";
		
	}else{
		alert('input some value');
	}
	
}

function get_filer(value){
	var max_price = 100;
	var search_item = value;
	if(search_item != ''){
		window.scrollTo(0, 0);
		var xmlhttpsignup;
		if(window.XMLHttpRequest){
			xmlhttpsignup = new XMLHttpRequest();
			
		}else{
			xmlhttpsignup = new ActiveXObject("Microsoft.XMLHTTP");
		}
		//remove country name india
		params = "search_item=" +search_item;
		
		xmlhttpsignup.open("POST","get_product.php",true);
		
		
		xmlhttpsignup.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttpsignup.setRequestHeader("Content-length", params.length);
		xmlhttpsignup.setRequestHeader("Connection", "close");
		
		xmlhttpsignup.onreadystatechange=function(){
		  if(xmlhttpsignup.status==200 && xmlhttpsignup.readyState==4){
			  document.getElementById("display_product").style.paddingBottom = '10px';
			   var returned_json = JSON.parse(xmlhttpsignup.responseText);
			   var currency_rs = '&#8377;';
			   document.getElementById('display_product').innerHTML='';
			   
			   for(var iota=0;iota<returned_json.length;iota++){
				   if(returned_json[iota]['old_price'] == 0){
					   returned_json[iota]['old_price'] = '';
				   }
				   var company;
				   if(returned_json[iota]['company'] == 'Flipkart'){
					   company = 'flipkart.jpg';
				   }else{
					   company = 'amazon.jpg';
				   }
				   returned_json[iota]['price'] = parseInt(returned_json[iota]['price']);
				   if(returned_json[iota]['price'] > max_price){
					   max_price = returned_json[iota]['price'];
				   }
				   document.getElementById('display_product').innerHTML += "<div  onclick=diplay_detail("+returned_json[iota]['id']+",'online') style='width:226px;margin-left:8px;margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+returned_json[iota]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(returned_json[iota]['title'].substr(0,30)).toLowerCase()+"</div></div><div style='width:100%;float:left;text-align:center;opacity:0.7;background-color:white;color:black;margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+ returned_json[iota]['price'] +"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+returned_json[iota]['old_price']+"</div></div><div style='position:absolute;top:2px;right:2px;width:30px;height:30px'><img src='images/"+company+"' style='width:30px;height:30px' /></div></div></div>";
			   }
			   document.getElementById("show_data").style.display = 'block';
			   document.getElementById("page_price_slider").setAttribute('max',max_price);
			   document.getElementById("slider_min_value").innerHTML = "&#8377;"+0+"-->";
			   document.getElementById("slider_max_value").innerHTML = max_price;
			   document.getElementById("page_price_slider").value = max_price;
		   }
		}
		
		xmlhttpsignup.send(params);
		
		document.getElementById('display_product').innerHTML = "<div style='width:100px;height:68px;margin:0 auto;'><img src='images/loading.gif' style='max-width:100px;max-height:68px' /></div>"; 
		document.getElementById("show_data").style.display = 'none';
		document.getElementById("twitter").style.display = "block";
		
		document.getElementById("twitter_holder").innerHTML = "<iframe width='250px' height='1200px' src='https://www.hashatit.com/hashtags/"+value+"/twitter/embed'></iframe>";
		get_offline(value);
	}else{
		alert('input some value');
	}
	
}

function get_comparison(title,company){

	var xmlhttpsignup;
	if(window.XMLHttpRequest){
		xmlhttpsignup = new XMLHttpRequest();
		
	}else{
		xmlhttpsignup = new ActiveXObject("Microsoft.XMLHTTP");
	}
	//remove country name india
	params = "title=" +title+"&company="+company;
	
	xmlhttpsignup.open("POST","compare_product.php",true);
	
	
	xmlhttpsignup.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttpsignup.setRequestHeader("Content-length", params.length);
	xmlhttpsignup.setRequestHeader("Connection", "close");
	
	xmlhttpsignup.onreadystatechange=function(){
	  if(xmlhttpsignup.status==200 && xmlhttpsignup.readyState==4){

	  	document.getElementById('pop_up').style.display = 'block';

		document.getElementById('display_product_item').innerHTML = xmlhttpsignup.responseText;  
	   }
	}
	
	xmlhttpsignup.send(params);
	
	document.getElementById('display_product_item').innerHTML = "<div style='width:100px;height:68px;margin:0 auto;'><img src='images/loading.gif' style='max-width:100px;max-height:68px' /></div>"; 
}
function _pop_up(){

	document.getElementById('pop_up').style.display = 'none';

}
function _popup_block(){

	document.getElementById('change_background').style.display = 'block';
}
function _get_filter_price(filter_option,table){
	
	var xmlhttpfilter;
	if(window.XMLHttpRequest){
		xmlhttpfilter = new XMLHttpRequest();
	}else{
		xmlhttpfilter = new ActiveXObject("Microsoft.XMLHTTP");
	}
	params = "filter=" +filter_option+"&table="+table;
	
	xmlhttpfilter.open("POST","filter.php",true);
	
	xmlhttpfilter.setRequestHeader("Content-length", params.length);
	xmlhttpfilter.setRequestHeader("Connection", "close");
	xmlhttpfilter.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	
	xmlhttpfilter.onreadystatechange=function(){
	  if(xmlhttpfilter.status==200 && xmlhttpfilter.readyState==4){
		   document.getElementById("display_product").style.paddingBottom = '10px';
		   var returned_json = JSON.parse(xmlhttpfilter.responseText);
		   var currency_rs = '&#8377;';
		   document.getElementById('display_product').innerHTML='';
		   
		   for(var iota=0;iota<returned_json.length;iota++){
			   
			   if(returned_json[iota]['old_price'] == 0){
				   returned_json[iota]['old_price'] = '';
			   }
			   var company;
			   if(returned_json[iota]['company'] == 'Amazon'){
				   company = 'amazon.jpg';
			   }else{
				   company = 'flipkart.jpg';
			   }
			   returned_json[iota]['price'] = parseInt(returned_json[iota]['price']);
			   
			   document.getElementById('display_product').innerHTML +=  "<div onclick=diplay_detail("+returned_json[iota]['id']+",'online') style='width:226px;margin-left:8px; margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+returned_json[iota]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(returned_json[iota]['title'].substr(0,30).toLowerCase())+"</div></div><div style='width:100%;float:left;text-align:center;opacity:0.7;background-color:white;color:black;margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+returned_json[iota]['price']+"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+returned_json[iota]['old_price']+"</div></div><div style='position:absolute;top:2px;right:2px;width:30px;height:30px'><img src='images/"+company+"' style='width:30px;height:30px' /></div></div></div>";
			   
		   }
	    }
	}
	xmlhttpfilter.send(params);
	document.getElementById('display_product').innerHTML = "<div style='width:100px;height:68px;margin:0 auto;'><img src='images/loading.gif' style='max-width:100px;max-height:68px' /></div>";
}

function change_product_visibility(val){
	var data = parseInt(document.getElementById("page_price_slider").value);
	
	var xmlfilter;
	if(window.XMLHttpRequest){
		xmlfilter = new XMLHttpRequest();
	}else{
		xmlfilter = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	parameter = 'value='+data+'&table_name='+val;
	
	xmlfilter.open("POST","get_filter_priced.php",true);
	
	xmlfilter.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlfilter.setRequestHeader("Content-length", parameter.length);
	xmlfilter.setRequestHeader("Connection", "close");
	
	xmlfilter.onreadystatechange = function(){
		if(xmlfilter.status = 200 && xmlfilter.readyState == 4){
			var data_filter = JSON.parse(xmlfilter.responseText);
			document.getElementById("display_product").style.paddingBottom = '10px';
		    document.getElementById("display_product").innerHTML = '';
			document.getElementById("slider_max_value").innerHTML = data;
			
			for(var pi=0;pi<data_filter.length;pi++){
			   if(data_filter[pi]['old_price'] == 0){
				   data_filter[pi]['old_price'] = '';
			   }
			   var company;
			   if(data_filter[pi]['company'] == 'Flipkart'){
				   company = 'flipkart.jpg';
			   }else{
				   company = 'amazon.jpg';
			   }
			   document.getElementById('display_product').innerHTML += "<div  onclick=diplay_detail("+data_filter[pi]['id']+",'online') style='width:226px;margin-left:8px;margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+data_filter[pi]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(data_filter[pi]['title'].substr(0,30)).toLowerCase()+"</div></div><div style='width:100%;float:left;text-align:center; opacity:0.7; background-color:white;color:black; margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+ data_filter[pi]['price'] +"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+data_filter[pi]['old_price']+"</div></div><div style='position:absolute;top:2px;right:2px;width:30px;height:30px'><img src='images/"+company+"' style='width:30px;height:30px' /></div></div></div>";
		   }
		}
	}
	xmlfilter.send(parameter);
}

function diplay_detail(id){
	alert(id);
}
function display_login_screen(){
	document.getElementById("pop_up").style.display = "block";
	document.getElementById("display_product_item").innerHTML = "";
	
	var login;
	if(window.XMLHttpRequest){
		login = new XMLHttpRequest();
	}else{
		login = new ActiveXObject('Microsoft.XMLHTTP');
	}
	login.open("POST","login_signup.php",true);
	
	login.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	login.setRequestHeader("Content-length",0);
	login.setRequestHeader("Connection","close");
	
	login.onreadystatechange = function(){
		if(login.status == 200 && login.readyState == 4){
			document.getElementById("display_product_item").innerHTML = login.responseText;
		}
	}
	login.send();
	
}
function xmlhttplogin(){
	var email = document.getElementById("email").value;
	var password = document.getElementById("password").value;
	
	var save_u_p;
	if(document.getElementById("remember").checked == true){
		save_u_p = 'true';
	}else{
		save_u_p = 'false';
	}
	
	if(email.length >= 6){
		if(password.length >= 6){
			
			var login_jx;
			if(window.XMLHttpRequest){
				login_jx = new XMLHttpRequest();
			}else{
				login_jx = new ActiveXObject('Microsoft.XMLHTTP');
			}
			
			login_parameter = "username="+email+"&password="+password;
			
			login_jx.open("POST","login.php",true);
			
			login_jx.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			login_jx.setRequestHeader("Content-length",login_parameter.length);
			login_jx.setRequestHeader("Connection","close");
			
			login_jx.onreadystatechange = function (){
				if(login_jx.status == 200 && login_jx.readyState == 4){
					if(login_jx.responseText == 'SuccessFul'){
						window.location = "vendors/index.php";
					}else{
						document.getElementById("invalid_credential").style.display = "block";
						document.getElementById("invalid_credential").innerHTML = login_jx.responseText;
					}
				}
			}
			login_jx.send(login_parameter);
			
		}else{
			document.getElementById("invalid_credential").style.display = "block";
			document.getElementById("invalid_credential").innerHTML = "Small Password Length";
		}
	}else{
		document.getElementById("invalid_credential").style.display = "block";
		document.getElementById("invalid_credential").innerHTML = "Small Email ID";
	}
}
 
function diplay_detail(id,status){
	//alert(id+status=onlineor offline);
	document.getElementById("pop_up").style.display = "none";
	var compare_jx;
	if(window.XMLHttpRequest){
		compare_jx = new XMLHttpRequest();
	}else{
		compare_jx = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	compare_parameter = "pro_id="+id+"&status="+status;
	compare_jx.open("POST","compare_product.php",false);
	
	compare_jx.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	compare_jx.setRequestHeader("Content-length",compare_parameter.length);
	compare_jx.setRequestHeader("Connection","close");
	
	compare_jx.onreadystatechange = function(){
		if(compare_jx.status == 200 && compare_jx.readyState == 4){
			document.getElementById("pop_up").style.display = "block";
			document.getElementById("display_product_item").innerHTML = compare_jx.responseText;
		}
	}
	compare_jx.send(compare_parameter);
}

function get_offline(offline_data){
	var offline_jx;
	if(window.XMLHttpRequest){
		offline_jx = new XMLHttpRequest();
	}else{
		offline_jx = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	param = "offline="+offline_data;
	alert(param);
	offline_jx.open("POST","offline.php",false);
	
	offline_jx.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	offline_jx.setRequestHeader("Content-length",param.length);
	offline_jx.setRequestHeader("Connection","close");
	
	offline_jx.onreadystatechange = function(){
		if(offline_jx.status == 200 && offline_jx.readyState ==4){
			document.getElementById("main_offline_section").style.display = "block";
			document.getElementById("main_offline_section").style.paddingBottom = "10px";
			document.getElementById("display_offline_products").innerHTML = "";
			var offline_product = JSON.parse(offline_jx.responseText);
			
			for(var pro =0 ;pro < offline_product.length; pro++){
				
				document.getElementById('display_offline_products').innerHTML += "<div  onclick=diplay_detail("+offline_product[pro]['id']+",'offline') style='width:226px;margin-left:8px;margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+offline_product[pro]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(offline_product[pro]['title'].substr(0,30)).toLowerCase()+"</div></div><div style='width:100%;float:left;text-align:center; opacity:0.7; background-color:white;color:black; margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+ offline_product[pro]['price'] +"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+offline_product[pro]['old_price']+"</div></div></div></div>";
			}
		}
	}
	offline_jx.send(param);

}

function add_to_cart(table,pro_id,pro_status,sell_status,small_image,price,shop_id,shop_name,pro_name){
	var cart;
	if(window.XMLHttpRequest){
		cart = new XMLHttpRequest();
	}else{
		cart = new ActiveXObject("Microsoft.XMLHTTP")
	}
	parameter = "table="+table+"&pro_id="+pro_id+"&pro_obtained="+pro_status+"&sell_status="+sell_status+"&image="+small_image+"&price="+price+"&shop_id="+shop_id+"&shop_name="+shop_name+"&pro_name="+pro_name;
	
	
	cart.open("POST","add_to_cart.php",false);
	
	cart.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	cart.setRequestHeader("Content-length",parameter.length);
	cart.setRequestHeader("Connection","close");
	
	cart.onreadystatechange = function(){
		if(cart.status == 200 && cart.readyState == 4){
			document.getElementById('cart_added').innerHTML = (cart.responseText);
		}
	}
	cart.send(parameter);
}

function get_cart_product(value){
	if(document.getElementById('show_cart_product').style.display == 'none'){
		
		var pro;
		if(window.XMLHttpRequest){
			pro = new XMLHttpRequest();
		}else{
			pro = new ActiveXObject('Microsoft.XMLHTTP');
		}
		param = 'tbl='+value;
		
		pro.open('POST','get_cart_pro.php',false);
		
		pro.setRequestHeader('Content-type','application/x-www-form-urlencoded');
		pro.setRequestHeader('Content-length',param.length);
		pro.setRequestHeader('Connection','close');
		
		pro.onreadystatechange = function(){
			if(pro.status == 200 && pro.readyState == 4){
				document.getElementById('show_cart_product').style.display  = 'block';
				document.getElementById('show_cart_product').innerHTML = (pro.responseText);
			}
		}
		pro.send(param);
	}else{
		document.getElementById('show_cart_product').style.display  = 'none';
	}
	
}
function remove_cart(value){
	var pro;
	if(window.XMLHttpRequest){
		pro = new XMLHttpRequest();
	}else{
		pro = new ActiveXObject('Microsoft.XMLHTTP');
	}
	param = 'tbl='+value;
	
	pro.open('POST','remove_cart.php',false);
	
	pro.setRequestHeader('Content-type','application/x-www-form-urlencoded');
	pro.setRequestHeader('Content-length',param.length);
	pro.setRequestHeader('Connection','close');
	
	pro.onreadystatechange = function(){
		if(pro.status == 200 && pro.readyState == 4){
			document.getElementById('show_cart_product').style.display  = 'block';
			document.getElementById('show_cart_product').innerHTML = (pro.responseText);
		}
	}
	pro.send(param);
}

function find_city(){
	var city_name = document.getElementById('find_city').value
	
	var city;
	if(window.XMLHttpRequest){
		city = new XMLHttpRequest();
	}else{
		city = new ActiveXObject('Microsoft.XMLHTTP');
	}
	param = 'city_name='+city_name;
	
	city.open('POST','get_shop.php',false);
	
	city.setRequestHeader('Content-type','application/x-www-form-urlencoded');
	city.setRequestHeader('Content-length',param.length);
	city.setRequestHeader('Connection','close');
	
	city.onreadystatechange = function(){
		if(city.status == 200 && city.readyState == 4){
			document.getElementById('show_cart_product').style.display  = 'block';
			document.getElementById('display_offline_products').innerHTML = (city.responseText);
		}
	}
	city.send(param);
}

function fetch_detail(time_line,user_id){
	var xmlhttp;
	if(window.XMLHttpRequest){
		xmlhttp = new XMLHttpRequest();
	}else{
		xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	parameter = "timeline="+time_line;
	xmlhttp.open("POST","vendor.php",true);
	
	xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length",parameter.length);
	xmlhttp.setRequestHeader("Connection","close");
	
	xmlhttp.onreadystatechange = function(){
		if(xmlhttp.status == 200 && xmlhttp.readyState == 4){
			if(time_line=='detail'){
				var multiple_json = JSON.parse(xmlhttp.responseText);
				
				document.getElementById("new_feed").innerHTML = '<div id="inner_new_feed" class="inner_new_feed"><div class="main_new_feed"><div style="width:100%;float:left;height:auto;"><div class="new_feed_personal_detail" id="new_feed_personal_detail"></div><div class="new_feed_description" id="new_feed_description"></div><div class="large_div_map"><div class="google_map_inner"><div class="google_map_holder" id="google_map_holder"></div></div></div></div></div></div>';
				
				//alert(multiple_json[1]['longitude']);
				document.getElementById("new_feed_personal_detail").innerHTML = "<div class='newfeed_mail_data'><div class='newfeed_mail_data_pad'><div class='newfeed_connect newfeed_connect_name' style='padding-left:4px;'>"+multiple_json[0]['vendor_name']+"</div><div class='newfeed_connect newfeed_connect_mail'><div>Mail:</div><div style='padding-left:4px;font-size:12px'>"+multiple_json[0]['email'].substr(0,40)+"</div></div><div class='newfeed_connect newfeed_connect_mobile'><div>Mob:</div><div style='padding-left:4px;'>"+multiple_json[0]['mobile']+"</div></div><div class='newfeed_connect newfeed_connect_joined_on'><div>Joined Us:</div><div style='padding-left:4px;'>"+multiple_json[0]['registered_on'].substr(0,10)+"</div></div><div class='newfeed_connect newfeed_connect_location'><div>Location:</div><div style='padding-left:4px'>"+multiple_json[1]['near_loc']+","+multiple_json[0]['city']+","+multiple_json[0]['pin_code']+"</div></div></div></div>";
				
				document.getElementById("new_feed_description").innerHTML = "<div style='font-size:16px;color:#333'>"+multiple_json[0]['shop_desc']+"</div>";
				fetch_detail('feedback');
				initialize(multiple_json[1]['latitude'],multiple_json[1]['longitude']);
				
				
			}
			else if(time_line == 'feedback'){
				var feedback = JSON.parse(xmlhttp.responseText);
				document.getElementById("main_feedback_block").innerHTML = "";
				for(var iota = 0; iota < feedback.length; iota++){
					document.getElementById("main_feedback_block").innerHTML += '<div class="all_same_feedback one_complete_feedback"><div style="padding:3px;"><div class="all_same_feedback feedback_user_detail"<div style="width:25px;float:left"><img src="'+feedback[iota]["smaller_icon"]+'" style="width:25px;height:25px;" /></div><div style="width:auto;float:left;padding:3px;font-size:16px;">'+feedback[iota]["name"]+'</div><div style="width:auto;float:right">'+feedback[iota]["date"]+'</div></div><div class="all_same_feedback"><hr style="width:100%;" /></div><div class="all_same_feedback feedback_user_comment"><div class="all_same_feedback" style="padding:3px">'+feedback[iota]["comment"]+'</div></div><div class="all_same_feedback"><div></div></div></div></div>';
				}
			}
			else if(time_line == 'product'){
				
				document.getElementById("new_feed").innerHTML = '<div id="inner_new_feed" class="inner_new_feed"><div><div style="width:100%;float:left;height:auto;" id="newfeed_product"></div></div></div>';
				document.getElementById("newfeed_product").innerHTML += '';
				document.getElementById("newfeed_product").innerHTML = '<div style="width:770px;margin:0 auto;margin-top:10px;padding:6px;"><div style="width:98%;float:left;border:3px solid green;padding-bottom:5px;"><div style="padding:5px"><div style="width:100%;float:left;text-align:center;font-size:24px;color:#333;padding:5px;text-decoration:underline;"><strong>Upload Product</strong></div><div style="width:100%;float:left"><div style="width:200px;height:250px;border:1px solid green;float:left"><form enctype="multipart/form-data" method="post"><label style="width:100%;height:250px;float:left;" id="parent_product_image"><span><input type="file" name="product_image" id="product_image" name="product_image" style="position:absolute;top:-1000px" onchange=upload_pro_image('+user_id+') /><img src="images/upload.png" style="width:200px;height:250px" /></span></label></form></div><div style="width:calc(100% - 220px); height:auto;float:left;margin-left:10px"><div style="width:100%;float:left;height:auto;"><div style="width:100%;float:left"><div style="width:100%;float:left;height:auto"><input type="text" name="title" id="title" placeholder="Product Name" style="width:100%;height:24px;padding:3px;outline:none; border:1px solid green"/></div></div><div style="width:100%;float:left;margin-top:10px;"><div style="width:100px;float:left;height:30px"><label style="width:100%;float:left;"><span style="margin-top:3px;float:left">&#x20B9;: </span><input type="text" name="price" id="price" placeholder="Price" style="float:left;width:75%;padding:3px;outline:none; border:1px solid green; border-radius:2px ;margin-left:4px"></label></div><div style="width:100px;float:left;height:30px;margin-left:10px"><label style="width:100%;float:left;"><span style="margin-top:3px;float:left">Color:</span><input type="color" name="color" id="color" placeholder="Color" style="float:left;width:35%;padding:3px;outline:none; border:1px solid green; border-radius:2px ;margin-left:4px"></label></div><div style="width:200px;float:left;height:30px;margin-left:10px"><label style="width:100%;float:left;"><span style="margin-top:3px;float:left">Company:</span><input type="text" name="brand" id="brand" placeholder="Brand" style="float:left;width:60%;padding:3px;outline:none; border:1px solid green; border-radius:2px ;margin-left:4px"></label></div></div><div style="width:100%;float:left;margin-top:10px"><div style="width:100%;float:left"><textarea type="text" name="product_desc" id="product_desc" placeholder="Description" style="width:99%;padding:5px;border:1px solid green;border-radius:3px;resize:none;height:60px; outline:none" ></textarea></div></div><div style="width:100%;float:left;margin-top:10px"><div style="width:100%;float:left"><div style="width:250px;float:left;"><label style="width:100%;float:left;"><span>Quantity:-</span><input type="number" name="quantity" id="quantity" placeholder="Quantity" style="width:20%;padding:4px"></label></div><div style="float:left"><div style="width:auto;float:left"><div style="position:relative"><div style="cursor:pointer" onClick=display("product_category")>Category<img src="popup.png" style="width:20px;height:20px;margin-left:4px;" /></div><div style="position:absolute;display:none;" id="product_category"><div style="width:500px;float:left;height:auto;;margin-left:-260px;margin-top:-160px"><div style="width:100%;float:left;border:1px solid green;;background-color:white"><div style="padding:5px"><div onClick=hide("product_category") style="cursor:pointer;position:absolute;right:1px;top:64px;border:1px solid green;background-color:black;color:white">Done!</div><div style="width:100%;float:left"><div style="width:24%;float:left;"><div style="width:100%;float:left"><label style="width:100%;float:left;">Men Section</label><hr><label style="width:100%;float:left"><input type="radio" name="check_category" value="Men Shirt">Shirt</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Men t-Shirt">T-shirt</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Men sneaker">Sneakers</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Men Shoe">Shoes</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Men Watch">Watch</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Men Watch">Wallet</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Men Trouser">Trouser</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Men jean">Jeans</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Men Combo">Combo Offer</label></div></div><div style="width:24%;float:left;border-left:1px solid green"><div style="width:95%;float:left;padding-left:5px"><label style="width:100%;float:left;">Women Section</label><hr><label style="width:100%;float:left"><input type="radio" name="check_category" value="Women Kurtas And Kurtis">Kurtas And Kurtis</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Saree">Saree</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Salwar Kurta And Dupatta">Salwar Kurta And Dupatta</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Heal">Heal</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Wedges">Wedges</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Hand Bag">Hand Bag</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Sling Bag">Sling Bag</label></div></div><div style="width:24%;float:left;border-left:1px solid green"><div style="width:95%;float:left;padding-left:5px"><label style="width:100%;float:left;">Sport Section</label><hr><label style="width:100%;float:left"><input type="radio" name="check_category" value="Cricket">Cricket</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Badminton">Badminton</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Football">Football</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Swimming">Swimming</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Table tennis">Table Tennis</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Tennis">Tennis</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Boxing">Boxing</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="BasketBall">BasketBall</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Show All Product">Show All Product</label></div></div><div style="width:24%;float:left;border-left:1px solid green"><div style="width:95%;float:left;padding-left:5px"><label style="width:100%;float:left;">Books</label><hr><label style="width:100%;float:left"><input type="radio" name="check_category" value="New Release">New Release</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Best Seller">Best Seller</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Pre-Order">Pre-Order</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Literature And Fiction">Literature And Fiction</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Comics And Graphics Nobel">Comics And Graphics Nobel</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Pens And Notebook">Pens And Notebook</label><label style="width:100%;float:left"><input type="radio" name="check_category" value="Academic Book">Academic Book</label></div></div></div></div></div></div></div></div></div></div></div><div><button onclick = upload_product('+user_id+') style="width:100%;height:40px;padding:7px;outline:none;background-color:blue;color:white;font-size:18px;border:1px solid green;margin-top:10px;cursor:pointer">Done!</button></div></div></div></div></div></div></div></div>';
				var product = JSON.parse(xmlhttp.responseText);
				for(var t= 0 ;t<product.length; t++){
					var old_price;
					var tez = parseInt(product[t]['old_price'],10);
					var tep = parseInt(product[t]['price'],10);
					if(tez > tep){
						old_price = "<strike>&#8377;"+product[t]['old_price']+"</strike>";
					}else{
						old_price = "";
					}
					
					document.getElementById("newfeed_product").innerHTML += "<div style='width:244px;float:left;margin-left:10px; margin-top:9px; border:1px solid green; height:270px;background-color:white'><div style='padding:5px'><div style='width:100%;float:left;height:auto;'><div class='all_same_feedback'><div style='width:100%;height:200px;text-align:center'><img src='"+product[t]['small_image']+"' style='mix-width:100%;max-height:200px' /></div><hr><div class='all_same_feedback'><div style='text-align:center;font-size:14px;'>"+product[t]['title']+"</div></div><hr><div class='all_same_feedback'><div style='width:61%;float:left'><strong>&#8377;"+product[t]['price']+"</strong></div><div style='width:35%;float:left'>"+old_price+"</div></div><div class='vendor_quick_view'>Quick View</div></div></div></div></div>";
				}
			}
			else if(time_line == 'update'){
				var product = JSON.parse(xmlhttp.responseText);
				document.getElementById("new_feed").innerHTML = '<div id="inner_new_feed" class="inner_new_feed"><div><div style="width:100%;float:left;height:auto;" id="newfeed_product"></div></div></div>';
				document.getElementById("newfeed_product").innerHTML = "";
				for(var t= 0 ;t<product.length; t++){
					var old_price;
					var tez = parseInt(product[t]['old_price'],10);
					var tep = parseInt(product[t]['price'],10);
					if(tez > tep){
						old_price = "<strike>&#8377;"+product[t]['old_price']+"</strike>";
					}else{
						old_price = "";
					}
					
					document.getElementById("newfeed_product").innerHTML += "<div id='product_"+product[t]['id']+"' style='width:244px;float:left;margin-left:10px; margin-top:9px; border:1px solid green; height:auto;background-color:white'><div style='padding:5px;position:relative'><div style='width:100%;float:left;height:auto; position:relative'><div class='all_same_feedback'><div style='width:100%;height:200px;text-align:center'><label id='parent_product_image' style='width:100%;float:left;height:auto;'><input type='file' style='position:absolute;top:-1000px;' name='product_image' id='product_image' onchange=upload_pro_image("+user_id+") /><span><img src='"+product[t]['small_image']+"' style='mix-width:100%;max-height:200px' id='product_image_org' /><span class='display_u_image'>Upload Image</span></span></label></div><hr><div class='all_same_feedback'><div style='text-align:center;font-size:14px;'><input name='new_product_name' id='new_product_name' type='text' value='"+product[t]['title']+"' style='border:1px solid green;margin-bottom:5px;' /></div></div><hr><div class='all_same_feedback'><div style='width:61%;float:left;padding:3px'><strong>New &#8377;<input type='number' id='new_price' name='new_price' value='"+product[t]['price']+"' style='width:50px;border-radius:2px;margin-top:-2px' /></strong></div><div style='width:35%;float:left'>Old &#8377;"+product[t]['price']+"</div></div></div></div><hr><div style='width:auto;float:left'><label>Quantity:<input type='number' name='new_quantity' id='new_quantity' style='width:40px;padding:3px;' value='"+product[t]['availaility']+"' /></label></div><div style='width:auto;float:left;margin-left:7px'><label>Color:<input type='color' name='new_color' id='new_color' style='width:40px;margin-top:-2px' value='#"+product[t]['color']+"' /></label></div><div style='width:100%;float:left;height:auto;margin-top:5px'><textarea style='resize:none;width:98%;float:left;height:50px;padding:2px;' id='new_desc' name='new_desc' placeholder='Product Description...' value='"+product[t]['product_desc']+"'></textarea></div><div style='margin-top:5px;margin-bottom:5px;width:100%;float:left'><button style='width:100%;float:left;outline:none; border:1px solid blue;background-color:blue; color:white;font-size:18px;' onclick=update_product("+user_id+","+product[t]['price']+","+product[t]['id']+")>Done!</button></div></div></div>";
				}
			}else if(time_line == 'offer'){
				document.getElementById("new_feed").innerHTML = "";
			}else{
				window.location = "http://localhost/shopping/";
			}
		}
	}
	xmlhttp.send(parameter);
	
}


function initialize(lat,lon) {
  var mapProp = {
      center:new google.maps.LatLng(lat,lon),
      zoom:15,
      mapTypeId:google.maps.MapTypeId.ROADMAP
    };
  var marker=new google.maps.Marker({
	   position:new google.maps.LatLng(lat,lon),
	   radius:20000,
	   strokeColor:"#0000FF",
 	   strokeOpacity:0.8,
	   strokeWeight:2,
	   fillColor:"#0000FF",
	   fillOpacity:0.4
	});
    marker.setMap(map);
	
    var map=new google.maps.Map(document.getElementById("google_map_holder"),mapProp);
	
}


function upload_product(d_1){
	var pro_name = document.getElementById("title").value;
	var pro_price = document.getElementById("price").value;
	pro_price = parseInt(pro_price);
	var pro_color = document.getElementById("color").value;
	var pro_desc = document.getElementById("product_desc").value;
	var pro_brand = document.getElementById("brand").value;
	var pro_quantity = document.getElementById("quantity").value;
	pro_quantity = parseInt(pro_quantity);
	var pro_category = get_category("check_category");
	
	
	if(product_image_data.length >= 4 && typeof(product_image_data) == 'string' && product_image_data != null){
		if(pro_name.length > 3){
			document.getElementById("title").style.border = '1px solid green';
			if(pro_price > 0){
				document.getElementById("price").style.border = '1px solid green';
				if(pro_color.length >= 2){
					if(pro_brand.length > 2){
						document.getElementById("brand").style.border = '1px solid green';
						if(pro_quantity > 0){
							document.getElementById("quantity").style.border = '1px solid green';
							if(typeof(pro_category) != 'undefined'){
								
								
								var product_jx;
								if(window.XMLHttpRequest){
									product_jx = new XMLHttpRequest();
								}else{
									product_jx = new ActiveXObject('Microsoft.XMLHTTP');
								}
								product_parameters = "image="+product_image_data+"&pro_name="+pro_name+"&pro_price="+pro_price+"&pro_color="+pro_color+"&pro_desc="+pro_desc+"&pro_brand="+pro_brand+"&pro_quantity="+pro_quantity+"&pro_category="+pro_category+"&user_id="+d_1;
								
								product_jx.open("POST","upload.php",true);
								
								product_jx.setRequestHeader("Content-type","application/x-www-form-urlencoded");
								product_jx.setRequestHeader("Content-length",product_parameters.length);
								product_jx.setRequestHeader("Connection","close");
								
								product_jx.onreadystatechange = function(){
									if(product_jx.status == 200 && product_jx.readyState == 4){
										if(product_jx.responseText == 'Suceeded'){
											document.getElementById("title").value = '';
											document.getElementById("price").value = '';
											document.getElementById("color").value = '';
											document.getElementById("product_desc").value = '';
											document.getElementById("brand").value = '';
											document.getElementById("quantity").value = '';
											
											document.getElementById('parent_product_image').innerHTML =  '<span><input type="file" name="product_image" id="product_image" name="product_image" style="position:absolute;top:-1000px" onchange=upload_pro_image('+d_1+') /><img src="images/upload.png" style="width:200px;height:250px" /></span>';
											
											document.getElementById("newfeed_product").innerHTML += "<div style='width:244px;float:left;margin-left:10px; margin-top:9px; border:1px solid green; height:270px;background-color:white'><div style='padding:5px'><div style='width:100%;float:left;height:auto;'><div class='all_same_feedback'><div style='width:100%;height:200px;text-align:center'><img src='"+product_image_data+"' style='mix-width:100%;max-height:200px' /></div><hr><div class='all_same_feedback'><div style='text-align:center;font-size:14px;'>"+pro_name+"</div></div><hr><div class='all_same_feedback'><div style='width:61%;float:left'><strong>&#8377;"+pro_price+"</strong></div></div><div class='vendor_quick_view'>Quick View</div></div></div></div></div>";
											
										}
									}
								}
								product_jx.send(product_parameters);
							}else{
								alert("Choose Product Category");
							}
						}else{
							document.getElementById("quantity").style.border = '1px solid red';
						}
					}else{
						document.getElementById("brand").style.border = '1px solid red';
					}
				}else{
					alert("Pick A Color");
				}
			}else{
				document.getElementById("price").style.border = '1px solid red';
			}
		}else{
			document.getElementById("title").style.border = '1px solid red';
		}
	}else{
		alert("Upload an Image");
	}
}


function get_category(get_category){
	var chk_arr =  document.getElementsByName(get_category);
	var chklength = chk_arr.length;             
	
	for(k=0;k< chklength;k++)
	{
		if(chk_arr[k].checked == true){
			return chk_arr[k].value;
		}
	} 
}


function upload_pro_image(d_1){
	var file_to_be_uploaded = document.getElementById('product_image').files[0];

	if(file_to_be_uploaded.name != 'undefined'){
		
		if(file_to_be_uploaded.size <= 2097152 ){

			document.getElementById('parent_product_image').innerHTML = "<div style='width:99%;float:left;height:250px;'><div id='display_file_name' style='width:95%;margin:0 auto;height:auto;position:relative;padding:2px;'><progress value='0' max=100' id='Progress' style='width:100%;height:246px;background-color:green;max-width:100%'></progress></div></div>";
			var formdata = new FormData();

			formdata.append("product_image",file_to_be_uploaded);

			if(window.XMLHttpRequest){

				var new_image_ajax = new XMLHttpRequest();
			}else{

				var new_image_ajax = new ActiveXObject('Microsoft.XMLHTTP');
			}
			var filename,image_source;
			new_image_ajax.open("POST", "uploading_image.php");

			new_image_ajax.onreadystatechange = function(){
				if(new_image_ajax.status == 200 && new_image_ajax.readyState == 4){
					product_image_data = new_image_ajax.responseText;
				}
			}


			new_image_ajax.upload.addEventListener("progress",function(event){
				document.getElementById('Progress').style.width = Math.round((event.loaded/event.total)*100)+"%";
			});


			new_image_ajax.addEventListener("load",function change_rotated_image(event){
				
				document.getElementById('parent_product_image').innerHTML = '<div style="background-color:white;padding:3px;width:200px;height:250px;text-align:center"><img src="'+product_image_data+'" style="text-align:center; max-width:194px;max-height:249px" id="product_image_org" /></div>';
			});
			
			new_image_ajax.addEventListener("error",function error_transferring(){
				alert();
			});

			new_image_ajax.addEventListener("abort",function cancelled(){
			});

			new_image_ajax.send(formdata);

		}else{

			var File_Size = (file_to_be_uploaded.size/1024)/1024
			alert("FIle Size Exceed The Limit Max Limit 2MB\nFile Size is : "+Math.round(File_Size*100)/100+"MB");
		}
	
	}else{
		alert("Try Uploadng File");
	}	
}

function update_product(u_1,old_price,product_id){
	//product_image_org
	var new_image = document.getElementById("product_image_org").src;
	var new_name = document.getElementById("new_product_name").value.trim();
	var new_quantity = document.getElementById("new_quantity").value;
	new_quantity = parseInt(new_quantity);
	var new_price = document.getElementById("new_price").value;
	new_price = parseInt(new_price);
	var new_color = document.getElementById("new_color").value;
	new_color = parseInt(new_color);
	var new_desc = document.getElementById("new_desc").value.trim();
	
	if(new_name !=''){
		document.getElementById("new_product_name").style.border='1px solid green';
		if(new_price >= 0){
			document.getElementById("new_price").style.border='1px solid green';
			if(new_quantity >= 0){
				document.getElementById("new_quantity").style.border='1px solid green';
				if(new_color !=''){
					document.getElementById("new_color").style.border='1px solid green';
					
						var update_jx;
						if(window.XMLHttpRequest){
							update_jx = new XMLHttpRequest();
						}else{
							update_jx = new ActiveXObject('Microsoft.XMLHTTP');
						}
						
						update_parameters = "pro_id="+product_id+"&pro_new_image="+new_image+"&pro_new_name="+new_name+"&new_quantity="+new_quantity+"&new_price="+new_price+"&new_color="+new_color+"&new_desc="+new_desc+"&old_price="+old_price+"&user_id="+u_1;
						
						var div_create = "product_"+product_id;
						
						update_jx.open("POST","update.php",true);
						
						update_jx.setRequestHeader("Content-type","application/x-www-form-urlencoded");
						update_jx.setRequestHeader("Content-length",update_parameters.length);
						update_jx.setRequestHeader("Connection","close");
						
						update_jx.onreadystatechange = function(){
							if(update_jx.status == 200 && update_jx.readyState == 4){
								if(update_jx.responseText == 'Suceeded'){
									document.getElementById(div_create).style.display = "none";
								}else{
									alert(update_jx.responseText);
								}
								
							}
						}
						update_jx.send(update_parameters);
					
				}else{
					document.getElementById("new_color").style.border='1px solid red';
				}
			}else{
				document.getElementById("new_quantity").style.border='1px solid red';
			}
		}else{
			document.getElementById("new_price").style.border='1px solid red';
		}
	}else{
		document.getElementById("new_product_name").style.border='1px solid red';
	}
}

function xmlhttplogin(){
	alert();
	var email = document.getElementById("email").value;
	var password = document.getElementById("password").value;
	
	var save_u_p;
	if(document.getElementById("remember").checked == true){
		save_u_p = 'true';
	}else{
		save_u_p = 'false';
	}
	
	if(email.length >= 6){
		if(password.length >= 6){
			
			var login_jx;
			if(window.XMLHttpRequest){
				login_jx = new XMLHttpRequest();
			}else{
				login_jx = new ActiveXObject('Microsoft.XMLHTTP');
			}
			
			login_parameter = "username="+email+"&password="+password;
			
			login_jx.open("POST","login.php",true);
			
			login_jx.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			login_jx.setRequestHeader("Content-length",login_parameter.length);
			login_jx.setRequestHeader("Connection","close");
			
			login_jx.onreadystatechange = function (){
				if(login_jx.status == 200 && login_jx.readyState == 4){
					if(login_jx.responseText == 'SuccessFul'){
						window.location = "http://localhost/shopping/vendors/index.php";
					}else{
						document.getElementById("invalid_credential").style.display = "block";
						document.getElementById("invalid_credential").innerHTML = login_jx.responseText;
					}
				}
			}
			login_jx.send(login_parameter);
			
		}else{
			document.getElementById("invalid_credential").style.display = "block";
			document.getElementById("invalid_credential").innerHTML = "Small Password Length";
		}
	}else{
		document.getElementById("invalid_credential").style.display = "block";
		document.getElementById("invalid_credential").innerHTML = "Small Email ID";
	}
}