<?php
	if(isset($_POST['city_name'])){
		mysql_connect('localhost','root','');
		
		mysql_select_db('vendors_shop');
		$city = $_POST['city_name'];
		
		$result = mysql_query("SELECT * FROM personal_detail WHERE city LIKE '$city'");
		mysql_connect("localhost","root","");
		mysql_select_db("vendors_shop");
		
		while($each_shop = mysql_fetch_assoc($result)){
			
			$id = $each_shop['id'];
			//done
			$profile = mysql_fetch_assoc(mysql_query("SELECT id,smaller_image FROM image_database WHERE category = 'Profile' AND shop_id='$id' ORDER BY id DESC LIMIT 1"));
			//done
			
			echo '<div style="width:48%;float:left;border-right:1px solid green">
					<a href="http://localhost/shopping/vendors/public_profile.php?id='.$id.'">
					<div style="padding:4px">
						<div style="width:100%;float:left">
							<div style="width:100px;float:left">
								<img src="vendors/'.$profile['smaller_image'].'" style="max-width:80px;max-height:80px">
							</div>
							<div style="width:calc(100% - 100px);float:left;padding-top:10px">
								'.$each_shop['shop_name'].'
							</div>
						</div>
					</div>
					</a>
				  </div>';
		}
	}
?>