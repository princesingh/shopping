<?php
if(isset($_POST["tbl"])){
	$id = $_POST["tbl"];
	mysql_connect("localhost","root","");
	mysql_select_db("shopping");
	session_start();
	$tale = $_SESSION["tbl_name"];
	mysql_query("DELETE FROM cart WHERE table_name ='$tale'  AND id= '$id'");
	echo mysql_num_rows(mysql_query("SELECT * FROM cart WHERE table_name = '$tale' "));
}

?>