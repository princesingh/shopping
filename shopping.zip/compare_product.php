<?php


session_start();

$_SESSION['visibilty'] = true;

if(isset($_POST['pro_id']) && isset($_POST['status'])){

	mysql_connect("localhost","root","");

	mysql_select_db("shopping");

	function get_client_ip_env() {
		$ipaddress = '';
		if (getenv('HTTP_CLIENT_IP'))
			$ipaddress = getenv('HTTP_CLIENT_IP');
		else if(getenv('HTTP_X_FORWARDED_FOR'))
			$ipaddress = getenv('HTTP_X_FORWARDED_FOR');
		else if(getenv('HTTP_X_FORWARDED'))
			$ipaddress = getenv('HTTP_X_FORWARDED');
		else if(getenv('HTTP_FORWARDED_FOR'))
			$ipaddress = getenv('HTTP_FORWARDED_FOR');
		else if(getenv('HTTP_FORWARDED'))
			$ipaddress = getenv('HTTP_FORWARDED');
		else if(getenv('REMOTE_ADDR'))
			$ipaddress = getenv('REMOTE_ADDR');
		else
			$ipaddress = 'UNKNOWN';

		return $ipaddress;
	}
	$ip = get_client_ip_env();

	$ip = "ipaddr".str_replace(':','00',trim($ip));

	$id = $_POST['pro_id'];


	$product = mysql_query("SELECT * FROM $ip WHERE id='$id' ORDER BY id DESC LIMIT 1");

	if((mysql_num_rows($product)) > 0){

		$each_product = mysql_fetch_assoc($product);
		
		$title = filter_var($each_product['title'],FILTER_SANITIZE_STRING);
		$title = str_replace(" ","_",$title);
		$title = str_replace("\"","",$title);
		$title = str_replace("\'","",$title);
		
		echo "<div style='width:100%;float:left;position:relative;border-bottom:2px solid green'>
				<div style='padding:10px'>
					<div style='width:100%;float:left'>
						<div style='width:400px;min-height:400px;float:left'>
							<img src='".$each_product['large_image']."' style='max-width:400px;max-height:400px' />
						</div> 
						<div style='width:300px;float:left;min-height:400px;'>
							<div style='width:100%;float:left;font-size:20px;color:green'>".$title."</div>
							<hr>
							<div>".substr($each_product['prod_desc'],0,500)."</div>
							<hr>
							<div style='width:100%;float:left;font-size:18px'>
								<div style='width:48%;float:left;text-align:center'>New Price: &#8377;".$each_product['price']."</div>
								<div style='width:48%;float:left;text-decoration:line-through;text-align:center'>Old Price: &#8377;".$each_product['old_price']."</div>
							</div>
							<hr>
							<div style='width:100%;float:lefttext-align:center;margin-top:20px;' onclick=add_to_cart('".$_SESSION['tbl_name']."','".$each_product['id']."','online','','".$each_product['small_image']."','".$each_product['price']."','".$title."')>
								<div style='width:120px;margin:0 auto; border:1px solid green;padding:10px; text-align:center;cursor:pointer' id='add_to_cart".$each_product['id']."'>
									Add To Cart
								</div>
							</div>
							<div style='width:100%;float:lefttext-align:center;margin-top:20px;'>
								<a style='color:green;text-decoration:none;padding:10px;font-size:16px;width:120px; margin: 0 auto' href='".$each_product['prod_link']."' target='_blank'>
									<div style='width:120px;margin:0 auto; border:1px solid green;padding:10px; text-align:center'>
										Buy
									</div>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div style='position:absolute;top:2px;left:2px'><img src='images/".strtolower($each_product['company']).".jpg' style='width:30px;height:30px' /></div>
				</div>
			  </div>";
			  
			  //similar product 
			  
			  $product_title = strtolower($each_product['title']);
			  $new_product_title = preg_replace('/[\[{\(].*[\]}\)]/U' , '', $product_title);
			  $product_title = filter_var($new_product_title,FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
			  
			  if($each_product['company'] == 'Flipkart'){
				  $similar_product = mysql_query("SELECT DISTINCT * FROM $ip WHERE (title LIKE '$product_title' OR title LIKE '%$product_title' OR title LIKE '$product_title%') AND (company ='Amazon') AND (id !='$id') ORDER BY id DESC LIMIT 20");
			  }elseif($each_product['company'] == 'Amazon'){
				  $similar_product = mysql_query("SELECT DISTINCT * FROM $ip WHERE (title LIKE '$product_title' OR title LIKE '%$product_title' OR title LIKE '$product_title%') AND (company ='Flipkart') AND (id !='$id') ORDER BY id DESC LIMIT 20");
			  }
			  if(mysql_num_rows($similar_product) > 0){
				  echo "<div style='width:100%;float:left'><div style='padding:5px;'><div style='width:100%;float:left'>Similar Products<br><hr>";
				  while($each_same = mysql_fetch_assoc($similar_product)){
					  echo "<div onclick=display_detail('".$each_same['id']."','online')  title='".$each_same['company']."' style='width:90px;height:90px;float:left;border-right:1px solid grey;margin-left:2px'><img src='".$each_same['small_image']."' style='max-width:80px;max-height:85px' /></div>";
				  }
				  echo "</div></div></div>";
			  }
	}

}


?>