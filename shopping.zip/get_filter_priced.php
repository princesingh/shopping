<?php

if(isset($_POST['value']) && isset($_POST['table_name'])){
	mysql_connect("localhost","root","");
	
	mysql_select_db("shopping");
	
	$table = $_POST['table_name'];
	$price = $_POST['value'];
	
	$last_result = mysql_fetch_assoc(mysql_query("SELECT search FROM $table ORDER BY id DESC LIMIT 1"));
	$last_value = $last_result['search'];
	
	$result_to_display = mysql_query("SELECT id,title,small_image,price,old_price,company FROM $table WHERE search= '$last_value' AND price < '$price' LIMIT 20");
	$each_result_2;
	while($new_result = mysql_fetch_assoc($result_to_display)){
		$each_result_2[] = $new_result;
	}
	echo json_encode($each_result_2);
	
}else{
	echo "Error";
}

?>
<?php
/*

	
	

	
*/
?>