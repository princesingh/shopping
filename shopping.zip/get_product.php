<?php
set_time_limit(100000);
error_reporting(0);
ini_set('E_ALL', false);

session_start();

$_SESSION['visibilty'] = true;

if(isset($_POST['search_item'])){
	$pri_na = $_POST['search_item'].str_replace('.','',date("m.d.y"));
	
	$_SESSION['search_product'] = $pri_na;
	
	//$brand = filter_var($brand, FILTER_SANITIZE_STRING);
	  mysql_connect("localhost","root","") or die(mysql_error());

	  mysql_select_db("shopping") or die(mysql_error());

	  function get_client_ip_env() {
	    $ipaddress = '';
	    if (getenv('HTTP_CLIENT_IP'))
	      $ipaddress = getenv('HTTP_CLIENT_IP');
	    else if(getenv('HTTP_X_FORWARDED_FOR'))
	      $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
	    else if(getenv('HTTP_X_FORWARDED'))
	      $ipaddress = getenv('HTTP_X_FORWARDED');
	    else if(getenv('HTTP_FORWARDED_FOR'))
	      $ipaddress = getenv('HTTP_FORWARDED_FOR');
	    else if(getenv('HTTP_FORWARDED'))
	      $ipaddress = getenv('HTTP_FORWARDED');
	    else if(getenv('REMOTE_ADDR'))
	      $ipaddress = getenv('REMOTE_ADDR');
	    else
	      $ipaddress = 'UNKNOWN';

	    return $ipaddress;
	  }

	  $ip = get_client_ip_env();

	  $ip = "ipaddr".str_replace(':','00',trim($ip));

	  $q = $_POST['search_item'];

	  $q = str_replace(' ', '+', $q);


  $uri = "https://affiliate-api.flipkart.net/affiliate/search/xml?query=".$q."&resultCount=100";

  $ch = curl_init($uri);

  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt_array($ch, array(
      CURLOPT_HTTPHEADER  => array('Fk-Affiliate-Id: kuldippur','Fk-Affiliate-Token: 44e2688a7cee457181f5c7d4e1a41544'),
      CURLOPT_RETURNTRANSFER  =>true,
      CURLOPT_VERBOSE     => 1
  ));
  if(!curl_exec($ch)){

      die('Error: "' . curl_error($ch) . '" - Code: ' . curl_errno($ch));
      echo 'hello';
  }
  $xml = curl_exec($ch);
  curl_close($ch);

  $data = simplexml_load_string($xml);

	foreach($data -> products -> productInfoList as $key){
	
		//here we are fetching small size image to make page load faster
		$image = $key  -> productBaseInfo -> productAttributes -> imageUrls ;
		foreach($image -> entry as $new_image){
	
		  $image_main_data = $new_image -> key;
	
		  if($image_main_data == '125x125'){
			$database_image_125 = $new_image -> value;
	
		  }else if($image_main_data == '275x275'){
			$database_image_275 = $new_image -> value;
	
		  }else if($image_main_data == '200x200'){
			$database_image_200 = $new_image -> value;
	
		  }else if($image_main_data == 'unknown'){
			$database_large_image = $new_image -> value;
	
		  }else{
			$database_image = 'image_not_available.jpg';
	
		  }
		}
	
		//here we are fetching title of product
		$product_title = $key  -> productBaseInfo -> productAttributes -> title ;
	
		//here we are fetching price
		$product_price = $key  -> productBaseInfo -> productAttributes -> sellingPrice -> amount ;
	
		//here we are fetching maximum price
		$max_price = $key  -> productBaseInfo -> productAttributes -> maximumRetailPrice -> amount;
	
		//here goes categories of product
		$product_categories = $key -> productBaseInfo  -> productIdentifier -> productId;
	
		//here product link will be displayed
		$product_link = $key -> productBaseInfo -> productAttributes -> productUrl;
	
		//product brand will be displayed here
		$brand = $key -> productBaseInfo -> productAttributes -> productBrand;
		
		//creating entity for discount
	
		$discount = ($max_price - $product_price)/$product_price;
	
		//product_desc will goes here
	
		$description = $key -> productBaseInfo -> productAttributes -> productDescription;
		
	
		//company
		$company = 'flipkart';
	
		//sanatizing product title 
		$product_title = filter_var($product_title,FILTER_SANITIZE_STRING);
		$sanatized_product_title = preg_replace('/[^A-Za-z0-9\-]/', '+', $product_title);
	
		//here color of sample will be displayed
		$product_color = $key -> productBaseInfo -> productAttributes -> color;
			  if(isset($database_image_200)){
				$image_main = $database_image_200;
			  }else if(isset($database_image_275)){
				$image_main = $database_image_275;
			  }else if(isset($database_image_125)){
				$image_main = $database_image_125;
			  }else{
			  }
			$product_categories = filter_var($product_categories, FILTER_SANITIZE_STRING);
			$product_link = filter_var($product_link,FILTER_SANITIZE_URL);
			$brand = filter_var($brand, FILTER_SANITIZE_STRING);
			$description = filter_var($description, FILTER_SANITIZE_STRING);
	
		  mysql_query("INSERT INTO $ip (title,category,brand,small_image,large_image,prod_desc,prod_link,price,old_price, company,discount,search) VALUES ('$product_title', '$product_categories', '$brand', '$image_main', '$database_large_image', '$description', '$product_link', '$product_price', '$max_price','Flipkart','$discount','$pri_na')");
	
	}
		// Your AWS Access Key ID, as taken from the AWS Your Account page
	  $aws_access_key_id = "AKIAJLERBKZGTQSPR6MQ";

		// Your AWS Secret Key corresponding to the above ID, as taken from the AWS Your Account page
	  $aws_secret_key = "lV/jltUVTQSHMPS10VC25U64ob65hsGJz+k1V6e6";

		// The region you are interested in
	  $endpoint = "webservices.amazon.com";

	  $uri = "/onca/xml";

	  $params = array(
	    "Service" => "AWSECommerceService",
	    "Operation" => "ItemSearch",
	    "AWSAccessKeyId" => "AKIAJLERBKZGTQSPR6MQ",
	    "AssociateTag" => "kuldiptalks-21",
	    "SearchIndex" => "All",
	    "Keywords" => $q,
	    "ResponseGroup" => "Images,ItemAttributes,Offers"
	  );

		// Set current timestamp if not set
	  if (!isset($params["Timestamp"])) {
	    $params["Timestamp"] = gmdate('Y-m-d\TH:i:s\Z');
	  }

		// Sort the parameters by key
	  ksort($params);

	  $pairs = array();

	  foreach ($params as $key => $value) {
	    array_push($pairs, rawurlencode($key)."=".rawurlencode($value));
	  }

	  // Generate the canonical query
	  $canonical_query_string = join("&", $pairs);

	  // Generate the string to be signed
	  $string_to_sign = "GET\n".$endpoint."\n".$uri."\n".$canonical_query_string;

	  // Generate the signature required by the Product Advertising API
	  $signature = base64_encode(hash_hmac("sha256", $string_to_sign, $aws_secret_key, true));

	  // Generate the signed URL
	  $request_url = 'http://'.$endpoint.$uri.'?'.$canonical_query_string.'&Signature='.rawurlencode($signature);

	  $ch = curl_init($request_url);

	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	  curl_setopt_array($ch, array(
	      CURLOPT_HTTPHEADER  => array('Fk-Affiliate-Id: kuldippur','Fk-Affiliate-Token: 44e2688a7cee457181f5c7d4e1a41544'),
	      CURLOPT_RETURNTRANSFER  =>true,
	      CURLOPT_VERBOSE     => 1
	  ));
	  if(!curl_exec($ch)){

	      die('Error: "' . curl_error($ch) . '" - Code: ' . curl_errno($ch));
	      echo 'hello';
	  }
	  $xml = curl_exec($ch);
	  curl_close($ch);

	  $data = simplexml_load_string($xml);

	  $i = 0;

	foreach($data -> Items -> Item as $new_item){

	  	$product_link = $new_item -> DetailPageURL;

	  	$small_image = $new_item  -> MediumImage -> URL;

	  	$large_image = $new_item -> LargeImage -> URL;

	  	$brand = $new_item  -> ItemAttributes -> Brand;

	  	$new_feature ='';

	  	foreach($new_item -> ItemAttributes -> Feature as $small_feature){

	  		$new_feature = $small_feature.'<br>'.$new_feature;
	  	}

	  	$maximun_price = $new_item  -> ItemAttributes -> ListPrice-> FormattedPrice;

	  	$product_title = $new_item  -> ItemAttributes -> Title;

	  	$least_price = $new_item  -> OfferSummary -> LowestNewPrice -> FormattedPrice;

	  	$category = $new_item  -> ASIN;

	  	$least_price = filter_var($least_price,FILTER_SANITIZE_NUMBER_FLOAT)/100 * 67.32;

	  	$maximun_price = filter_var($maximun_price,FILTER_SANITIZE_NUMBER_FLOAT)/100 * 67.32;

	  	$product_title = filter_var($product_title,FILTER_SANITIZE_STRING);

	  	$sanatized_product_title = preg_replace('/[^A-Za-z0-9\-]/', '+', $product_title);

	  	$discount = ($maximun_price - $least_price)/$least_price;

	  	$product_link = filter_var($product_link,FILTER_SANITIZE_URL);

	  	$small_image = filter_var($small_image,FILTER_SANITIZE_URL);

	  	$large_image = filter_var($large_image,FILTER_SANITIZE_URL);

	  	$new_feature = filter_var($new_feature,FILTER_SANITIZE_STRING);

	  	$brand = filter_var($brand,FILTER_SANITIZE_STRING);

     mysql_query("INSERT INTO $ip (title,category,brand,small_image,large_image,prod_desc,prod_link,price,old_price, company,discount,search) VALUES ('$product_title', '$category','$brand','$small_image','$large_image','$new_feature', '$product_link', '$least_price', '$maximun_price', 'Amazon','$discount','$pri_na')");

	}
	
	$result_to_display = mysql_query("SELECT id,title,small_image,price,old_price,company FROM $ip WHERE search ='$pri_na' ORDER BY id DESC LIMIT 20");
	while($each_result = mysql_fetch_assoc($result_to_display)){
		
		$each_result_2[] = $each_result;
	}
	echo json_encode($each_result_2);
}

?>