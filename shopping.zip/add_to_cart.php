<?php
//"="+table+"&="+pro_id+"&="+pro_status+"&="+sell_status+"&="+small_image+"&="+price
	if(isset($_POST["table"]) &&isset($_POST["pro_id"]) &&isset($_POST["pro_obtained"]) &&isset($_POST["sell_status"]) &&isset($_POST["image"]) &&isset($_POST["price"]) && isset($_POST["shop_id"]) && isset($_POST["shop_name"])&& isset($_POST["pro_name"])){
		mysql_connect("localhost","root","");
		mysql_select_db("shopping");
		$pro_id = trim($_POST["pro_id"]);
		$pro_obt = $_POST["pro_obtained"];
		$sell_status = $_POST["sell_status"];
		$image = $_POST["image"];
		$price = $_POST["price"];
		$table = $_POST["table"];
		$shop_name = $_POST["shop_name"];
		$shop_id = $_POST["shop_id"];
		$title = $_POST["pro_name"];
		session_start();
		$table = trim($_SESSION["tbl_name"]);
		
		//echo mysql_num_rows($product_bool)." ";		//table=ipaddr00001&pro_id=359&pro_obtained=online&sell_status=&image=http://ecx.images-amazon.com/images/I/41YOVzvGQaL._SL160_.jpg&price=1205
		$title = filter_var($title,FILTER_SANITIZE_STRING);
		$title = str_replace(' ','_',$title);
		$title = str_replace(',','_',$title);
		$title = str_replace('\'','',$title);
		$title = str_replace('\"','',$title);
		
		$product_bool = mysql_num_rows(mysql_query("SELECT id FROM cart WHERE pro_id = '$pro_id' AND table_name = '$table'"));
		if($product_bool == 0){
			mysql_query("INSERT INTO cart (pro_id,pro_image,status,sell_status,shop_id,pro_title,price,table_name,shop_name) VALUES('$pro_id','$image', '$pro_obt','$sell_status','$shop_id','$title','$price','$table','$shop_name')");
		}else{
			
		}
		
		
		echo $return_val = mysql_num_rows(mysql_query("SELECT * FROM cart WHERE table_name='$table'"));
		
	}else{
		echo "price";
	}

?>